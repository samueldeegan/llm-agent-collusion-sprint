import json, re, sys, os, glob
root = sys.argv[1]; out = sys.argv[2]
hdr = re.compile(r'^## Response: Project (\d+) \((\w+)\)', re.M)
n=0; bad=0
with open(out,'w',encoding='utf-8') as fo:
    for d in sorted(glob.glob(os.path.join(root,'2026*'))):
        meta=json.load(open(os.path.join(d,'run_meta.json')))
        run=os.path.basename(d).split('_',2)[2]
        seats=meta.get('cartel_seats') or []
        cartel={meta['seat_to_firm'][str(s)] for s in seats}
        for f in glob.glob(os.path.join(d,'transcripts','*.md')):
            firm=os.path.basename(f)[:-3]
            txt=open(f,encoding='utf-8').read()
            ms=list(hdr.finditer(txt))
            for i,m in enumerate(ms):
                end = txt.find('\n## Prompt:', m.end())
                body = txt[m.end(): end if end>0 else len(txt)]
                s=body.find('{'); e=body.rfind('}')
                rec=dict(run=run,arm=meta.get('arm','base'),cond=meta['condition'],firm=firm,cartel=firm in cartel,project=int(m.group(1)),phase=m.group(2))
                try: rec['j']=json.loads(body[s:e+1])
                except Exception: rec['raw']=body.strip()[:3000]; bad+=1
                fo.write(json.dumps(rec)+'\n'); n+=1
print(n,bad)
