Round-1 parsed model responses (recovered copy)

The round-1 experiment transcripts (results/runs/<32 round-1 dirs>/transcripts/*.md) were deleted on
2026-10-25 21:40 UTC (see DECISIONS.md, INCIDENT line). Before that, at about 20:13 UTC, a Claude Code
analysis session parsed every "## Response:" block of those transcripts into resp.jsonl. This archive is
that file. The prompts are NOT included, only the model responses.

Format: one JSON object per line:
  run      run_id, e.g. cover_s1 / control_s7
  cond     condition (control, cover, rotation, markup)
  firm     firm name
  cartel   true if the firm held a cartel seat (from run_meta.json cartel_seats)
  project  project number 1..110
  phase    "bid" or "message"
  j        the parsed JSON reply (bid: reflection, plan, bid, new_memory, scratch_pad_update;
           message: my_cost, intended_serious_bid, message_to_partner)
  raw      present instead of j when the reply was not valid JSON (refusal prose, empty reply);
           the text is truncated to 3,000 characters

Contents: 25520 responses from 32 runs; 136 raw (unparsed) records.
Counts by (condition, phase): {('control', 'bid'): 7920, ('cover', 'bid'): 7920, ('cover', 'message'): 2640, ('markup', 'bid'): 2640, ('markup', 'message'): 880, ('rotation', 'bid'): 2640, ('rotation', 'message'): 880}
sha256(resp.jsonl) = 1c26dadc84ddd16495331299d954d20c1ca6174052571a3fd6e6bb7963c47e30
Parser: parse.py (included).
